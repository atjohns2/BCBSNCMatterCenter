﻿$(document).ready(function(){
    $.getScript("http://" + oEnvironmentConfiguration.azureSiteName + ".azurewebsites.net/app/directives/heading.directive.js");
    $.getScript("http://" + oEnvironmentConfiguration.azureSiteName + ".azurewebsites.net/app/directives/common.directive.js");
    $.getScript("http://" + oEnvironmentConfiguration.azureSiteName + ".azurewebsites.net/app/home.controller.js");
    $.getScript("http://" + oEnvironmentConfiguration.azureSiteName + ".azurewebsites.net/app/navigation.controller.js");
    $.getScript("http://" + oEnvironmentConfiguration.azureSiteName + ".azurewebsites.net/app/services/auth.service.js");
    $.getScript("http://" + oEnvironmentConfiguration.azureSiteName + ".azurewebsites.net/app/services/api.service.js");
    $.getScript("http://" + oEnvironmentConfiguration.azureSiteName + ".azurewebsites.net/app/matter/matter.resources.js");
    $.getScript("http://" + oEnvironmentConfiguration.azureSiteName + ".azurewebsites.net/app/matter/matters.controller.js");
    $.getScript("http://" + oEnvironmentConfiguration.azureSiteName + ".azurewebsites.net/app/matter/matterusers.controller.js");
    $.getScript("http://" + oEnvironmentConfiguration.azureSiteName + ".azurewebsites.net/app/dashboard/settings.resources.js");
    $.getScript("http://" + oEnvironmentConfiguration.azureSiteName + ".azurewebsites.net/app/dashboard/settings.controller.js");
    $.getScript("http://" + oEnvironmentConfiguration.azureSiteName + ".azurewebsites.net/app/home.resources.js");
    $.getScript("http://" + oEnvironmentConfiguration.azureSiteName + ".azurewebsites.net/app/home.controller.js");
    $.getScript("http://" + oEnvironmentConfiguration.azureSiteName + ".azurewebsites.net/app/dashboard/documentdashboard.resources.js");
    $.getScript("http://" + oEnvironmentConfiguration.azureSiteName + ".azurewebsites.net/app/dashboard/documentdashboard.controller.js");
    $.getScript("http://" + oEnvironmentConfiguration.azureSiteName + ".azurewebsites.net/app/dashboard/matterdashboard.resources.js");
    $.getScript("http://" + oEnvironmentConfiguration.azureSiteName + ".azurewebsites.net/app/dashboard/matterdashboard.controller.js");
    $.getScript("http://" + oEnvironmentConfiguration.azureSiteName + ".azurewebsites.net/app/matter/upload.js");
    $.getScript("http://" + oEnvironmentConfiguration.azureSiteName + ".azurewebsites.net/app/document/documents.controller.js");
    $.getScript("http://" + oEnvironmentConfiguration.azureSiteName + ".azurewebsites.net/app/document/document.resources.js");
    $.getScript("http://" + oEnvironmentConfiguration.azureSiteName + ".azurewebsites.net/app/directives/drag.directive.js");
    $.getScript("http://" + oEnvironmentConfiguration.azureSiteName + ".azurewebsites.net/app/directives/drop.directive.js");
    $.getScript("http://" + oEnvironmentConfiguration.azureSiteName + ".azurewebsites.net/app/matter/createMatter.controller.js");
});



