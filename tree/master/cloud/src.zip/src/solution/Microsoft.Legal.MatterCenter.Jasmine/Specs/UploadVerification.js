﻿//// ***********************************************************************
// Author           : MAQ USER
// Created          : 31-08-2016
//
// ***********************************************************************
// <copyright file="UploadVerification.js" company="MAQSoftware">
//  Copyright (c) . All rights reserved.
// </copyright>
// <summary>Test suite for verify the upload file</summary>
// ***********************************************************************

describe("Upload Controller test suite", function () {
    "use strict";
    var upload = matter.upload.uploadManager;

    describe("Verification of closeNotificationDialog function", function () {
        it("Should close notification dialog box", function () {
            //// **************** This method can not be verified becuase to it is not defined within controller ****************

            ////cm.closeNotificationDialog();
            ////expect(cm.IsDupliacteDocument).toBe(false);
        });
    });
});

