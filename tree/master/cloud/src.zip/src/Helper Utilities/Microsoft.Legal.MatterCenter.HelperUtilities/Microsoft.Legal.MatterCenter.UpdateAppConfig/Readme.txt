UpdateAppConfig

To Execute this utility separately:
1. Populate build of Provider Service into Service Publish folder present in UpdatedAppConfig solution folder
2. Populate build of SharePointAppWeb into Web Publish folder present in UpdatedAppConfig solution folder
3. Copy the Static Content from deployment folder.

Note: Utility cannot be executed successfully if above changes are not performed. Refer Matter Center deployment guide for more detail on how to prepare build.
