ProvisionWebdashboard

To Execute this utility separately. Populate appropriate content into Static Content folder present in the ProvisionWebdashboard solution folder.
This content should be same as in deployment folder. Refer Matter Center deployment guide for more details on how to prepare build.